#include <stdio.h>
#include "menu.c"
int main()
{
    menu();
    return 0;
}
