
char *product[] = {"Red hoodie", "Green hoodie", "black hoodie",
                      "White hoodie", "Gray hoodie"};

float price[TAM] = {1000.01, 2000.02, 3000.03, 4000.04, 5000.05};

//stock and cart
int numbers[2][TAM] ={{50, 48, 50, 45, 50},//stock
                    {0, 0, 0, 0, 0}};//cart
int not_empty=0;