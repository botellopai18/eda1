enum boolean load_products(struct node p[TAM])
{
    FILE *f;
    f=fopen("stock/db.txt", "r");
    if(f!=NULL)
    {
        for(int i=0; i<TAM; i++)
        {
            fscanf(f, "%s %f %d %d", p[i].item, &p[i].price, &p[i].stock, &p[i].cart);
        }
        fclose(f);
        return true;
    }
    return false;
}