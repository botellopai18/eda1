void welcome()
{
    printf("Welcome to the online store!\n");
    printf("You can press... \n");
    printf("1 to show products \n");
    printf("2 to add a product into your cart \n");
    printf("3 to delete a product from your cart \n");
    printf("4 to show your cart \n");
    printf("5 to generate your ticket \n");
    printf("6 to exit \n");
}