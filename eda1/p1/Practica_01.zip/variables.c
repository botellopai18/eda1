#define TAM 5
#define MAX 30
char product[TAM][MAX] = {"Red hoodie", "Green hoodie", "black hoodie",
                      "White hoodie", "Gray hoodie"};
float price[TAM] = {10.01, 20.02, 30.03, 40.04, 50.05};

//stock and cart
int numbers[2][TAM] ={{50, 48, 50, 45, 50},//stock
                    {0, 0, 0, 0, 0}};//cart